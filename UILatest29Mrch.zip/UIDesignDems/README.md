# BottomNavigationBarWithFragments

How to create Bottom Navigation Bar/VIew in Android

Watch full video link:
https://youtu.be/OV25x3a55pk


![bottom](https://user-images.githubusercontent.com/68380115/153709096-b73bc91f-05c0-4ff4-854d-1019f6fb4106.png)
