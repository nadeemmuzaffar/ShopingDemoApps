package easy.tuto.bottomnavigationfragmentdemo;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.util.Base64;
import android.util.Log;

import java.security.MessageDigest;

/**
 * Created by Gaurav Yadav on 2/3/17.
 */

public class AppBaseContext extends Application {

    private static AppBaseContext baseContext;

    public static AppBaseContext getAppBaseContext() {
        return baseContext;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        baseContext = this;
       // checkHasKey();
    }

    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        // MultiDex.install(this);
    }

    private void checkHasKey() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo("com.smartydating", PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String sign = Base64.encodeToString(md.digest(), Base64.DEFAULT);
                Log.d("MY KEY HASH:", sign);
                //Toast.makeText(getApplicationContext(),sign,Toast.LENGTH_LONG).show();
            }
        } catch (PackageManager.NameNotFoundException e) {
        } catch (Exception e) {
        }
    }
}
