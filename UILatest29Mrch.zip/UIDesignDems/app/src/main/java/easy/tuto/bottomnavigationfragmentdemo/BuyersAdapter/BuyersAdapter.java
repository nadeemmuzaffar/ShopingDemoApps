package easy.tuto.bottomnavigationfragmentdemo.BuyersAdapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import easy.tuto.bottomnavigationfragmentdemo.R;

public class BuyersAdapter extends RecyclerView.Adapter<BuyersAdapter.ViewHolder> {
    private Context bContext;
    private List<BuyesModel> buyesModels;

    public BuyersAdapter(Context bContext, List<BuyesModel> buyesModels) {
        this.bContext = bContext;
        this.buyesModels = buyesModels;
    }

    @NonNull
    @Override
    public BuyersAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(bContext).inflate(R.layout.single_buyes,parent,false);


        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BuyersAdapter.ViewHolder holder, int position) {

        holder.buyer_name.setText(buyesModels.get(position).getBuyesname());
        holder.discount.setText(buyesModels.get(position).getBuyesdicount());
        holder.views.setText(buyesModels.get(position).getBuyesviews());
        holder.buyesImg.setImageResource(buyesModels.get(position).getBuyesImg());

    }

    @Override
    public int getItemCount() {
        return buyesModels.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView buyer_name,discount,views,bug;
        ImageView buyesImg;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            buyer_name=itemView.findViewById(R.id.tv_buyers);
            discount=itemView.findViewById(R.id.tv_discount);
            views=itemView.findViewById(R.id.tv_views);
            bug=itemView.findViewById(R.id.tv_bug);
            buyesImg=itemView.findViewById(R.id.imgbug);
        }
    }
}
