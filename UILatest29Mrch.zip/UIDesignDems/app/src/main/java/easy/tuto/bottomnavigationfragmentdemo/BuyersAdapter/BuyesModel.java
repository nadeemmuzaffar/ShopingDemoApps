package easy.tuto.bottomnavigationfragmentdemo.BuyersAdapter;

public class BuyesModel {

    private String buyesname, buyesdicount, buyesviews, buyesbug;
    private int buyesImg;

    public BuyesModel(String buyesname, String buyesdicount, String buyesviews, String buyesbug, int buyesImg) {
        this.buyesname = buyesname;
        this.buyesdicount = buyesdicount;
        this.buyesviews = buyesviews;
        this.buyesbug = buyesbug;
        this.buyesImg = buyesImg;
    }

    public String getBuyesname() {
        return buyesname;
    }

    public void setBuyesname(String buyesname) {
        this.buyesname = buyesname;
    }

    public String getBuyesdicount() {
        return buyesdicount;
    }

    public void setBuyesdicount(String buyesdicount) {
        this.buyesdicount = buyesdicount;
    }

    public String getBuyesviews() {
        return buyesviews;
    }

    public void setBuyesviews(String buyesviews) {
        this.buyesviews = buyesviews;
    }

    public String getBuyesbug() {
        return buyesbug;
    }

    public void setBuyesbug(String buyesbug) {
        this.buyesbug = buyesbug;
    }

    public int getBuyesImg() {
        return buyesImg;
    }

    public void setBuyesImg(int buyesImg) {
        this.buyesImg = buyesImg;
    }
}
