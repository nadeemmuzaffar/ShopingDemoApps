package easy.tuto.bottomnavigationfragmentdemo.Login;

import com.android.volley.Response;

import org.json.JSONException;
import org.json.JSONObject;

public interface NetworkManager extends Response.ErrorListener{

        void onReceiveResponse(final int requestId, JSONObject jsonObject)throws JSONException;
}