package easy.tuto.bottomnavigationfragmentdemo.Login;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;

import easy.tuto.bottomnavigationfragmentdemo.AppBaseContext;
import easy.tuto.bottomnavigationfragmentdemo.Login.NetworkManager;


/**
 * Created by Gaurav Yadav.
 */

public class RequestManager {

    public final String TAG = "VolleyPatterns";
    private Context mContext;
    private RequestQueue mRequestQueue;
    private HashMap<String, String> headers;


    public RequestManager(Context context) {
        mContext = context;
    }

    //for json post request
    public Request<?> sendJsonPostRequest(final NetworkManager obj, Response.ErrorListener errorListener, final int requestId, String urlPath, JSONObject jsonRequest) {
        JsonObjectRequest request = new JsonObjectRequest(urlPath, jsonRequest, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            // Parsing json object response
                            // response will be a json object
                            obj.onReceiveResponse(requestId, response);


                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(mContext, "Network Error. ", Toast.LENGTH_LONG).show();
                        }
                    }
                }, errorListener);
//        request.setShouldCache(shouldCache);
        request.setTag(this);
        request.setTag(getHeaders());
        request.setRetryPolicy(
                new DefaultRetryPolicy(20 * 1000, 1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        //setRetryPolicy(new DefaultRetryPolicy(20 * 1000, 1, 1.0f));

        addToRequestQueue(request, request.getUrl());
        return request;
    }

    //for json array post request
//    public Request<?> sendJsonArrayPostRequest(final NetworkManager obj, Response.ErrorListener errorListener , final int requestId, String urlPath, JSONArray jsonArray ) {
//        JsonArrayRequest request =
//                new JsonArrayRequest(Request.Method.POST,urlPath, jsonArray, new Response.Listener<JSONArray>() {
//
//
//                    @Override
//                    public void onResponse(JSONArray response) {
//
//                        try {
//                            // Parsing json object response
//                            // response will be a json object
//                            obj.onReceiveResponse(requestId, response.getJSONObject(0));
//
//
//                        } catch (Exception e) {
//                            e.printStackTrace();
////                            CommonUtils.showNetworkErrorMessage(context,context.getString(R.string.try_again));
//                        }
//                    }
//                }, errorListener);
////        request.setShouldCache(shouldCache);
//        request.setTag(this);
//        request.setHeaders(getHeaders());
//        request.setRetryPolicy(
//                new DefaultRetryPolicy(60 * 1000, 2, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
//        //setRetryPolicy(new DefaultRetryPolicy(20 * 1000, 1, 1.0f));
//
//        addToRequestQueue(request,request.getUrl());
//        return request;
//    }

    //for json get request
    public Request<?> sendJsonGetRequest(final NetworkManager obj, Response.ErrorListener errorListener, final int requestId, String urlPath) {
        JsonObjectRequest request = new JsonObjectRequest(urlPath, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {

                try {
                    // Parsing json object response
                    // response will be a json object
                    obj.onReceiveResponse(requestId, response);


                } catch (Exception e) {
                    Toast.makeText(mContext, "Network Error. ", Toast.LENGTH_LONG).show();
                }
            }
        }, errorListener);
        request.setTag(this);
        request.setRetryPolicy(
                new DefaultRetryPolicy(20 * 1000, 1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        addToRequestQueue(request, request.getUrl());
        return request;
    }


    //for multipart/image request
//    public void sendJsonMultipartRequest(final NetworkManager obj, final int requestId,Ha) {
//        MultipartUtilityRequest multipartUtilityRequest=new MultipartUtilityRequest(urlPath);
//        Activity activity=null;
//        activity.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                obj.onReceiveResponse();
//            }
//        });
//        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, urlPath, new Response.Listener<NetworkResponse>() {
//            @Override
//            public void onResponse(NetworkResponse response) {
//                String resultResponse = new String(response.data);
//                try {
//                    obj.onReceiveResponse(requestId, new JSONObject(resultResponse));
//                }catch (Exception ex){}
//            }
//        },errorListener)
//        { @Override
//        protected Map<String, DataPart> getByteData() {
//            Map<String, DataPart> params = new HashMap<>();
//            // file name could found file base or direct access from real path
//            // for now just get bitmap data from ImageView
//            params.put("avatar", new DataPart("file_avatar.jpg", null, "image/jpeg"));
//            params.put("cover", new DataPart("file_cover.jpg", null, "image/jpeg"));
//
//            return params;
//        };
//        request.setTag(this);
//        request.setRetryPolicy(
//                new DefaultRetryPolicy(60 * 1000, 2, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
//        addToRequestQueue(request,request.getUrl());
//        return request;
////        MultipartRequest request=new MultipartRequest(urlPath,map,image_path, new Response.Listener<String>() {
////            @Override
////            public void onResponse(String response) {
////                Log.e(TAG, "Success Response: " + response.toString());
////                try {
////                    obj.onReceiveResponse(requestId, new JSONObject(response));
////                }catch (Exception ex){}
////
////            }
////        }, errorListener);
////        request.setTag(this);
////        request.setRetryPolicy(
////                new DefaultRetryPolicy(60 * 1000, 2, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
////        addToRequestQueue(request,request.getUrl());
////        return request;
//    }

    /**
     * Adds the specified request to the global queue, if tag is specified
     * then it is used else Default TAG is used.
     *
     * @param req
     * @param tag
     */
    private <T> void addToRequestQueue(Request<T> req, String tag) {
        // set the default tag if tag is empty
        req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);

//        VolleyLog.d("Adding request to queue: %s", req.getUrl());

        getRequestQueue().add(req);
    }

    /**
     * Adds the specified request to the global queue using the Default TAG.
     *
     * @param req
     */
    private <T> void addToRequestQueue(Request<T> req) {
        // set the default tag if tag is empty
        req.setTag(TAG);

        getRequestQueue().add(req);
    }

    /**
     * Cancels all pending requests by the specified TAG, it is important
     * to specify a TAG so that the pending/ongoing requests can be cancelled.
     *
     * @param tag
     */
    public void cancelPendingRequests(Object tag) {
        if (mRequestQueue != null) {
            mRequestQueue.cancelAll(tag);
        }
    }

    /**
     * @return The Volley Request queue, the queue will be created if it is null
     */
    private RequestQueue getRequestQueue() {
        // lazy initialize the request queue, the queue instance will be
        // created when it is accessed for the first time
        if (mRequestQueue == null) {
            mRequestQueue = Volley.newRequestQueue(AppBaseContext.getAppBaseContext());
        }

        return mRequestQueue;
    }

    private HashMap<String, String> getHeaders() {

        if (headers == null) {
            headers = new HashMap<String, String>();
            headers.put("Content-Type", "application/json");
        }
        // return RequestManager headers;
        return (HashMap<String, String>) headers;
    }

    public void sendImageRequest(final NetworkManager obj, final int requestId, String url) {
        ImageRequest ir = new ImageRequest(url, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap response) {
//                obj.onReceiveResponse(requestId, response.);
            }
        }, 0, 0, null, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                obj.onErrorResponse(error);
            }
        });
    }
}
