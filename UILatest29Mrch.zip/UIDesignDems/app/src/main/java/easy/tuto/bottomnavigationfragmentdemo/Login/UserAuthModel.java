package easy.tuto.bottomnavigationfragmentdemo.Login;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import easy.tuto.bottomnavigationfragmentdemo.Login.UserAuthModeldata;

public class UserAuthModel {

    private ArrayList<UserAuthModeldata> userAuthModeldata;

    public UserAuthModel(JSONObject jsonObject) {
        parseResponse(jsonObject);
    }

    private void parseResponse(JSONObject jsonObject) {
        try {
            if (jsonObject != null) {
                if (jsonObject.has("result")) {
                    JSONArray jsonArray = jsonObject.getJSONArray("result");
                    if (jsonArray != null && jsonArray.length() > 0) {
                        userAuthModeldata = new ArrayList<>();

                        for (int k = 0; k < jsonArray.length(); k++) {
                            String  userName = null,password = null;
                            JSONObject object = jsonArray.getJSONObject(k);
                            if (object.has("USERID")) {
                                userName = object.getString("USERID");
                            }
                            if (object.has("USER_PASSWORD_ANDROID")) {
                                password = object.getString("USER_PASSWORD_ANDROID");
                            }
                            userAuthModeldata.add(new UserAuthModeldata(userName,password));
                        }
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public ArrayList<UserAuthModeldata> getUserAuthModeldata() {
        return userAuthModeldata;
    }

    public void setUserAuthModeldata(ArrayList<UserAuthModeldata> userAuthModeldata) {
        this.userAuthModeldata = userAuthModeldata;
    }
}
