package easy.tuto.bottomnavigationfragmentdemo.Login;

public class WebServicesUrls {

    final static String BASE_URL="http://122.176.50.103:7980/unloading/";
    public static final String API_USER_AUTH=BASE_URL+"userAuth.php";

}
