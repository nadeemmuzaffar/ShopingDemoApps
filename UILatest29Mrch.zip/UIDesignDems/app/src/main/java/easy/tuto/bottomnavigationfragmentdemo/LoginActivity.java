package easy.tuto.bottomnavigationfragmentdemo;

import static easy.tuto.bottomnavigationfragmentdemo.Login.WebServicesUrls.API_USER_AUTH;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import easy.tuto.bottomnavigationfragmentdemo.Login.NetworkManager;
import easy.tuto.bottomnavigationfragmentdemo.Login.RequestManager;
import easy.tuto.bottomnavigationfragmentdemo.Login.UserAuthModel;
import easy.tuto.bottomnavigationfragmentdemo.Login.UserAuthModeldata;

public class LoginActivity extends AppCompatActivity implements NetworkManager, Response.ErrorListener{
    private EditText userName, password;
    private Button signInBtn;
    private ProgressDialog progressDialog;
    private final int ID_USER_AUTH = 1;
    private UserAuthModel userAuthModel;
    private List<UserAuthModeldata> userAuthModeldata;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        userName = (EditText) findViewById(R.id.email_sign_in);
        password = (EditText) findViewById(R.id.password_sign_in);
        signInBtn = (Button) findViewById(R.id.sign_in_btn);

        signInBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (userName.getText().toString() != null && userName.getText().toString().length() > 0
                        && password.getText().toString() != null && password.getText().toString().length() > 0) {

                    String userNameTxt = userName.getText().toString();
                    String passwordTxt = password.getText().toString();
                    callUserAuth(userNameTxt, passwordTxt);
//                    Intent moveToNextScreen = new Intent(getApplicationContext(), FormScreen.class);
//                    startActivity(moveToNextScreen);
//                    finish();
                }
            }
        });
    }

    private void callUserAuth(String userName, String password){

        try {
            progressDialog.setMessage(getResources().getString(R.string.loader_text));
            showDialog();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("User_Id", userName);
            jsonObject.put("Password", password);
            new RequestManager(getApplicationContext()).sendJsonPostRequest(this, this, ID_USER_AUTH, API_USER_AUTH, jsonObject);
        }catch (Exception ex){
            hideDialog();
            Toast.makeText(getApplicationContext(), "Network problem.Please try again.", Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    private void showDialog() {
        if (!progressDialog.isShowing())
            progressDialog.show();
    }

    private void hideDialog() {
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }
    @Override
    public void onReceiveResponse(int requestId, JSONObject jsonObject) throws JSONException {

        try {
            if (requestId == ID_USER_AUTH) {
                userAuthModel = new UserAuthModel(jsonObject);
                userAuthModeldata = userAuthModel.getUserAuthModeldata();

                if (userAuthModeldata != null && !userAuthModeldata.isEmpty()) {

                    for (UserAuthModeldata userAuthModeldata1 : userAuthModeldata) {

                        if (userName.getText().toString().trim().equalsIgnoreCase(userAuthModeldata1.getUsername().trim())
                                && password.getText().toString().trim().equals(userAuthModeldata1.getPassword().trim())) {

                            SharedPreferences.Editor editor = getSharedPreferences("User_Details", MODE_PRIVATE).edit();
                            editor.putString("user_name", userAuthModeldata1.getUsername().trim());
                            editor.putString("password", userAuthModeldata1.getPassword().trim());
                            editor.apply();
                            Intent moveToNextScreen = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(moveToNextScreen);
                            finish();

                        }else{
                            hideDialog();
                            Toast.makeText(getApplicationContext(), "Please check Username or password and try again.", Toast.LENGTH_LONG).show();
                        }
                    }
                }
                hideDialog();
            }else{
                hideDialog();
                Toast.makeText(getApplicationContext(), "Please try again.", Toast.LENGTH_LONG).show();
            }
        } catch (Exception ex) {
            hideDialog();
            ex.printStackTrace();
        }

    }
    @Override
    public void onErrorResponse(VolleyError error) {
        hideDialog();

        Log.d("TAG", "My volley error : "+error.getLocalizedMessage());
        Toast.makeText(getApplicationContext(), "Please try again"+error.getLocalizedMessage(), Toast.LENGTH_LONG).show();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }


}