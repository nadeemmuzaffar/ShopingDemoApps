package easy.tuto.bottomnavigationfragmentdemo;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import easy.tuto.bottomnavigationfragmentdemo.Adapter.InstaStoriesAdapter;
import easy.tuto.bottomnavigationfragmentdemo.BuyersAdapter.BuyersAdapter;
import easy.tuto.bottomnavigationfragmentdemo.BuyersAdapter.BuyesModel;
import easy.tuto.bottomnavigationfragmentdemo.ShopAdapter.ModelShop;
import easy.tuto.bottomnavigationfragmentdemo.ShopAdapter.ShopAdapter;
import easy.tuto.bottomnavigationfragmentdemo.model.InstaModel;


public class SettingsFragment extends Fragment {
    private RecyclerView shopRecy,buyerRecy;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_settings, container, false);

        shopRecy=view.findViewById(R.id.shopRecy);
        buyerRecy=view.findViewById(R.id.buyerRecy);


        List<ModelShop> shops = new ArrayList<>();
        shops.add(new ModelShop("Gifts",R.drawable.gift));
        shops.add(new ModelShop("On Sale",R.drawable.gift));
        shops.add(new ModelShop("Discounts",R.drawable.gift));
        shops.add(new ModelShop("Save",R.drawable.gift));
        shops.add(new ModelShop("GIFT",R.drawable.gift));
        shops.add(new ModelShop("GIFT",R.drawable.gift));

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL); // set Horizontal Orientation
        shopRecy.setLayoutManager(linearLayoutManager);
        ShopAdapter shopAdapter = new ShopAdapter((Context) getContext(), (ArrayList<ModelShop>) shops);
        shopRecy.setAdapter(shopAdapter);


        List<BuyesModel> buyesModels = new ArrayList<>();
        buyesModels.add(new BuyesModel("Presale Starts","Discount-100$ OFF","12,578 views","nadeem",R.drawable.image4));
        buyesModels.add(new BuyesModel("Presale Starts","Discount-100$ OFF","12,578 views","nadeem",R.drawable.image2));
        buyesModels.add(new BuyesModel("Presale Starts","Discount-100$ OFF","12,578 views","nadeem",R.drawable.image3));
        buyesModels.add(new BuyesModel("Presale Starts","Discount-100$ OFF","12,578 views","nadeem",R.drawable.image5));
        LinearLayoutManager buyerLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL); // set Horizontal Orientation
        buyerRecy.setLayoutManager(buyerLayoutManager);
        BuyersAdapter buyersAdapter = new BuyersAdapter((Context) getContext(), (ArrayList<BuyesModel>) buyesModels);
        buyerRecy.setAdapter(buyersAdapter);
        return view;
    }
}