package easy.tuto.bottomnavigationfragmentdemo.ShopAdapter;

public class ModelShop {

    static String[] nameArray = {"Gas", "Insurance", "Electronics", "Other Services"};
    private String shopname;
    private int shopImage;

    public ModelShop(String shopname, int gift) {
        this.shopname = shopname;
    }

    public String getShopname() {
        return shopname;
    }

    public void setShopname(String shopname) {
        this.shopname = shopname;
    }

    public int getShopImage() {
        return shopImage;
    }

    public void setShopImage(int shopImage) {
        this.shopImage = shopImage;
    }
}
