package easy.tuto.bottomnavigationfragmentdemo.ShopAdapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import easy.tuto.bottomnavigationfragmentdemo.R;

public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.shoviewholdeer> {

    private Context shopContext;
    private List<ModelShop> modelShops;

    public ShopAdapter(Context shopContext, List<ModelShop> modelShops) {
        this.shopContext = shopContext;
        this.modelShops = modelShops;
    }

    @NonNull
    @Override
    public ShopAdapter.shoviewholdeer onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(shopContext).inflate(R.layout.single_shop,parent,false);
        return new shoviewholdeer(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ShopAdapter.shoviewholdeer holder, int position) {

        holder.shopname.setText(modelShops.get(position).getShopname());
        holder.shopImg.setImageResource(modelShops.get(position).getShopImage());
    }

    @Override
    public int getItemCount() {
        return modelShops.size();
    }

    public class shoviewholdeer extends RecyclerView.ViewHolder {
        private TextView shopname;
        private ImageView shopImg;
        public shoviewholdeer(@NonNull View itemView) {
            super(itemView);

            shopname=itemView.findViewById(R.id.tv_gft);
            shopImg=itemView.findViewById(R.id.gft_img);
        }
    }
}
